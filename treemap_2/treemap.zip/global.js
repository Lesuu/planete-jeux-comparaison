export let currentTreemapExplanation = "";

export function setCurrentTreemapExplanation(value) {
    currentTreemapExplanation = value;
}